TRUCK DEALER SIMULATOR
=======================

এটি একটি মোবাইল-ফ্রেন্ডলি 2D Truck Dealership Game-এর প্রথম ভার্সন।

ফাইল:
- index.html  = গেমের মূল পেজ
- style.css   = গেমের ডিজাইন
- game.js     = গেমের সব হিসাব/কেনাবেচা/আপগ্রেড/সেভ সিস্টেম
- assets/     = পরে ট্রাকের ছবি/সাউন্ড রাখার জায়গা

মোবাইল দিয়ে চালানো:
1. ZIP ফাইলটি Extract করুন।
2. index.html ফাইলটি কোনো HTML editor/preview app দিয়ে খুলুন।
3. index.html, style.css এবং game.js একই folder-এ রাখবেন।
4. Internet ছাড়া গেমের মূল অংশ চলবে, কারণ কোনো external library নেই।

বর্তমান গেমে:
- শুরু টাকা ৳500,000
- ৫টি Truck
- Buy system
- Delivery mission
- Level system
- Upgrade system
- LocalStorage save system
- Reset button

গুরুত্বপূর্ণ:
এটি প্রথম playable version। পরে আমরা truck image, showroom animation,
map, sound, fuel, driver, আরও mission এবং Android APK/AAB build system যোগ করতে পারি।

Play Store-এর জন্য পরে WebView/Capacitor-এর মাধ্যমে Android App বানানো যাবে।
