const TRUCKS = [
  {id:1,name:"Mini Truck",price:120000,speed:50,cargo:2,level:1,icon:"🚚"},
  {id:2,name:"City Truck",price:220000,speed:65,cargo:4,level:1,icon:"🚛"},
  {id:3,name:"Heavy Truck",price:380000,speed:75,cargo:8,level:2,icon:"🚛"},
  {id:4,name:"Super Hauler",price:650000,speed:90,cargo:14,level:3,icon:"🚛"},
  {id:5,name:"Mega Truck",price:1000000,speed:100,cargo:20,level:4,icon:"🚛"}
];

let state = JSON.parse(localStorage.getItem("truckDealerSave")) || {
  money:500000, level:1, deliveries:0, owned:[]
};

function save(){localStorage.setItem("truckDealerSave",JSON.stringify(state));}
function money(n){return n.toLocaleString("en-US");}

function render(){
  document.getElementById("money").textContent=money(state.money);
  document.getElementById("level").textContent=state.level;
  document.getElementById("truckCount").textContent=state.owned.length;
  document.getElementById("deliveries").textContent=state.deliveries;

  const list=document.getElementById("truckList");
  list.innerHTML="";
  TRUCKS.forEach(t=>{
    const locked=state.level<t.level;
    const owned=state.owned.some(x=>x.id===t.id);
    const canBuy=state.money>=t.price && !owned && !locked;
    list.innerHTML += `
      <div class="truck ${locked?'locked':''}">
        <div class="truck-icon">${t.icon}</div>
        <h3>${t.name} ${locked?'<span class="badge">Level '+t.level+'</span>':''}</h3>
        <div class="price">৳${money(t.price)}</div>
        <div class="spec">⚡ Speed: ${t.speed}<br>📦 Cargo: ${t.cargo} ton</div>
        <button class="buy" ${canBuy?'':'disabled'} onclick="buyTruck(${t.id})">
          ${locked?'🔒 Locked':owned?'✅ Owned':'কিনুন'}
        </button>
      </div>`;
  });

  const garage=document.getElementById("garage");
  if(!state.owned.length){
    garage.innerHTML='<p class="empty">এখনও কোনো ট্রাক কেনা হয়নি।</p>';
  }else{
    garage.innerHTML=state.owned.map((t,i)=>`
      <div class="owned">
        <div class="owned-left">
          <div class="owned-icon">${t.icon}</div>
          <div><h3>${t.name}</h3><p>Upgrade: ${t.upgrade}/3</p></div>
        </div>
        <button class="upgrade" onclick="upgradeTruck(${i})">🔧 Upgrade ৳${money(30000*(t.upgrade+1))}</button>
      </div>`).join("");
  }
}

function buyTruck(id){
  const t=TRUCKS.find(x=>x.id===id);
  if(!t || state.level<t.level || state.money<t.price || state.owned.some(x=>x.id===id)) return;
  state.money-=t.price;
  state.owned.push({...t,upgrade:0});
  save(); render();
  alert(t.name+" কেনা হয়েছে! 🚛");
}

function upgradeTruck(i){
  const t=state.owned[i];
  if(t.upgrade>=3){alert("এই ট্রাকের সর্বোচ্চ Upgrade হয়ে গেছে।");return;}
  const cost=30000*(t.upgrade+1);
  if(state.money<cost){alert("Upgrade করার জন্য পর্যাপ্ত টাকা নেই।");return;}
  state.money-=cost;
  t.upgrade++;
  t.speed+=5;
  t.cargo+=1;
  save(); render();
}

document.getElementById("deliveryBtn").addEventListener("click",()=>{
  if(!state.owned.length){alert("প্রথমে অন্তত একটি ট্রাক কিনুন।");return;}
  const best=Math.max(...state.owned.map(t=>t.cargo+t.upgrade));
  const reward=25000+best*5000;
  state.money+=reward;
  state.deliveries++;
  if(state.deliveries%3===0) state.level=Math.min(5,state.level+1);
  save(); render();
  alert("ডেলিভারি সফল! 🎉 আপনি ৳"+money(reward)+" পেয়েছেন।");
});

document.getElementById("resetBtn").addEventListener("click",()=>{
  if(confirm("সব গেম ডাটা মুছে ফেলবেন?")){
    localStorage.removeItem("truckDealerSave");
    location.reload();
  }
});

render();
